const express = require("express");

const app = express();
app.use(express.json({ limit: "1mb" }));

const PORT = process.env.PORT || 3000;
const VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN;
const WHATSAPP_TOKEN = process.env.WHATSAPP_ACCESS_TOKEN;
const PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_NUMBER_ID;
const GRAPH_API_VERSION = process.env.GRAPH_API_VERSION || "v23.0";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

const studioInfo = `
Business: RS Makeup Studio by Artist Srashti Dwivedi
Website: https://rsmakeupstudio.in/
Phone: +91 9039733705
Email: rsmakeupstudio16@gmail.com
Website-listed address: 1st Floor, 18, University Road, Tagore Nagar, Anupam Nagar, Govindpuri, Gwalior, Madhya Pradesh 474011.
The studio website describes Srashti Dwivedi as founder and lead artist, with 7+ years of hands-on experience and Lakme Academy certification.
Website-listed services include bridal makeup, face makeup, eye makeup, hair styling, rental jewellery, facial and bleaching, threading, manicure and pedicure, body polishing, hair colour, keratin and hair smoothing. Always say availability must be confirmed if uncertain.
Do not invent service prices, discounts, business hours, policies or appointment availability.
`;

const systemPrompt = `
You are RS Beauty Assistant, the friendly AI assistant for RS Makeup Studio by Artist Srashti Dwivedi in Gwalior, India.
Reply in simple Hindi or Hinglish matching the customer's language. Be warm, concise, respectful and professional. Use a few emojis, not too many.
Clearly identify yourself as the studio's AI assistant if asked. Never pretend to be Srashti personally.
Studio information:
${studioInfo}

Your tasks:
- Answer questions about the studio and listed services.
- Help with booking enquiries by asking for the requested service, event date, preferred time, and customer name, one or two questions at a time.
- Never claim a booking is confirmed. Say the studio team must confirm the final booking and availability.
- Never make up prices. If asked for a price and no verified price is in the supplied information, say the team will confirm it.
- If a customer asks for a human, give the studio phone number +91 9039733705.
- Give practical, general beauty tips when requested. Do not diagnose skin conditions or promise medical results.
- Do not request sensitive information or pressure customers.
- For daily updates, only send promotional messages to people who have opted in. This bot does not initiate daily broadcasts by itself.
Keep each answer around 1-5 short sentences.
`;

async function sendWhatsAppText(to, body) {
  if (!WHATSAPP_TOKEN || !PHONE_NUMBER_ID) {
    console.error("Missing WHATSAPP_ACCESS_TOKEN or WHATSAPP_PHONE_NUMBER_ID.");
    return;
  }

  const url = `https://graph.facebook.com/${GRAPH_API_VERSION}/${PHONE_NUMBER_ID}/messages`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${WHATSAPP_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to,
      type: "text",
      text: { preview_url: false, body }
    })
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error("WhatsApp send error:", response.status, JSON.stringify(data));
  }
}

async function askGemini(message) {
  if (!GEMINI_API_KEY) {
    return "Namaste! 💕 Main RS Beauty Assistant hoon. Aap Bridal Makeup, Party Makeup, Hair & Beauty Services, Price Enquiry ya Appointment Enquiry mein se kis cheez mein help chahte hain?";
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: systemPrompt }] },
      contents: [{ role: "user", parts: [{ text: message }] }],
      generationConfig: { temperature: 0.5, maxOutputTokens: 300 }
    })
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error("Gemini error:", response.status, JSON.stringify(data));
    return "Maaf kijiye, abhi main jawab generate nahi kar pa rahi. Kripya studio team se +91 9039733705 par contact karein. 💕";
  }

  return data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim()
    || "Maaf kijiye, abhi jawab nahi mil paaya. Studio team se +91 9039733705 par contact karein.";
}

app.get("/", (_req, res) => {
  res.status(200).send("RS Makeup Studio WhatsApp assistant is running.");
});

// Meta webhook verification
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  if (mode === "subscribe" && token && token === VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

// Incoming WhatsApp messages
app.post("/webhook", async (req, res) => {
  // Acknowledge Meta immediately; process messages after returning 200.
  res.sendStatus(200);

  try {
    const entries = req.body?.entry || [];
    for (const entry of entries) {
      for (const change of (entry.changes || [])) {
        const value = change.value || {};
        const messages = value.messages || [];

        for (const msg of messages) {
          if (msg.type !== "text" || !msg.from || !msg.text?.body) continue;
          const userText = msg.text.body.trim();

          // Simple quick response for location/contact.
          const lower = userText.toLowerCase();
          let answer;
          if (["location", "address", "address bhejo", "location bhejo"].some(x => lower.includes(x))) {
            answer = "📍 Website par listed address: 1st Floor, 18, University Road, Tagore Nagar, Anupam Nagar, Govindpuri, Gwalior, Madhya Pradesh 474011. Aane se pehle location confirm karne ke liye +91 9039733705 par contact kar sakte hain.";
          } else if (["human", "srashti", "team", "call"].some(x => lower.includes(x))) {
            answer = "Bilkul 💕 Studio team se baat karne ke liye +91 9039733705 par contact karein. Main AI assistant hoon aur final booking team confirm karegi.";
          } else {
            answer = await askGemini(userText);
          }

          await sendWhatsAppText(msg.from, answer);
        }
      }
    }
  } catch (err) {
    console.error("Webhook processing error:", err);
  }
});

app.get("/health", (_req, res) => res.json({ ok: true, service: "rs-makeup-whatsapp-bot" }));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`RS Makeup Studio bot listening on port ${PORT}`);
});
